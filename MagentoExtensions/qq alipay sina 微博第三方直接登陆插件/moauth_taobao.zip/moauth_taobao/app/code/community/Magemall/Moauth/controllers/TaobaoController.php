<?php
include dirname ( __FILE__ ) . "/BaseController.php"; class Magemall_Moauth_TaobaoController extends Magemall_Moauth_BaseController { protected $oauth_name = 'taobao'; const AUTHORIZE_URL = "https://oauth.taobao.com/authorize"; const TOKEN_URL = "https://oauth.taobao.com/token"; protected function _getReturnUrl() { return $this->_getCallbackUrl(); } public function loginAction() { $config = $this->_getConfig(); $redirect = self::AUTHORIZE_URL; $data = array( 'response_type' => 'code', 'client_id' => $config['appid'], 'state' => 1, 'redirect_uri' => $this->_getReturnUrl() ); $redirect .= '?' . http_build_query($data); $this->_redirectUrl($redirect); } public function callbackAction() { $config = $this->_getConfig(); $code = $this->getRequest()->getQuery('code'); $url = self::TOKEN_URL; $postfields= array( 'grant_type' => 'authorization_code', 'client_id' => $config['appid'], 'client_secret' => $config['appkey'], 'code' => $code, 'redirect_uri' =>$this->_getReturnUrl()); $data = $this->sendRequestAsPost($url, $postfields); $result = Zend_Json::decode($data, Zend_Json::TYPE_OBJECT); if(empty($result->taobao_user_id)) { $this->getResponse()->setBody('Login Failed'); return; } $oauthUser = Mage::getModel('moauth/user'); $oauthUser->setService('taobao'); $oauthUser->setServiceId($result->taobao_user_id); $customId = $oauthUser->getCustomerId(); if ($customId != null) { $customer = Mage::getModel('customer/customer')->load($customId); $session = Mage::getSingleton('customer/session'); $session->setEscapeMessages(true); $session->setCustomerAsLoggedIn($customer); $body = <<<JS
<script language="javascript">
try {
window.opener.location.reload();
}
catch (e){
}
window.close();
</script>
JS;
$this->getResponse()->setBody($body); return; } else { $session = Mage::getSingleton('customer/session'); $session->setOauthType('taobao') ->setOauthOpenId($result->taobao_user_id) ->setOauthUsername($result->taobao_user_nick); $this->_redirect('moauth/login/complete'); return; } } } 