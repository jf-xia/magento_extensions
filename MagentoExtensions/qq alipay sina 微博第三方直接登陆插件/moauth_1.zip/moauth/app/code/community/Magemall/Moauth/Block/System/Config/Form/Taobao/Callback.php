<?php
 class Magemall_Moauth_Block_System_Config_Form_Taobao_Callback extends Mage_Adminhtml_Block_System_Config_Form_Fieldset { protected $_dummyElement; protected $_fieldRenderer; protected $_values; public function render (Varien_Data_Form_Element_Abstract $element) { $baseUrl = Mage::getUrl('moauth/taobao/callback'); $html = '<tr id="row_moauth_taobao_callback">
        		<td class="label">
        		<label for="moauth_taobao_callback"> 回调地址</label></td>
        		<td class="value"><p>' . $baseUrl . '</p></td><td class="scope-label">&nbsp;</td>
        		</tr>'; return $html; } } 