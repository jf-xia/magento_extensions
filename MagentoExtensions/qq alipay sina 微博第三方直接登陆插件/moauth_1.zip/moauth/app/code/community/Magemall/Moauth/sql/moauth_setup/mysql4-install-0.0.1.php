<?php
 $installer = $this; $installer->startSetup(); $installer->run("
-- DROP TABLE IF EXISTS {$this->getTable('moauth_user')};
CREATE TABLE {$this->getTable('moauth_user')} (
   `map_id` int(10) unsigned NOT NULL AUTO_INCREMENT,    
   `service` char(8) NOT NULL,
   `service_id` char(40) NOT NULL,   
   `customer_id` int(10) unsigned NOT NULL,
   `created_at` datetime NOT NULL,   
   PRIMARY KEY (`map_id`),
   UNIQUE KEY `service_id` (`service`,`service_id`)      
) ENGINE=MyISAM DEFAULT CHARSET=utf8;  
"); $installer->endSetup(); 