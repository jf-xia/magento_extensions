<?php
 require_once("alipay.config.php"); require_once("lib/alipay_notify.class.php"); ?>
<!DOCTYPE HTML>
<html>
    <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<?php
$alipayNotify = new AlipayNotify($aliapy_config); $verify_result = $alipayNotify->verifyReturn(); if($verify_result) { $user_id = $_GET['user_id']; $token = $_GET['token']; echo "验证成功<br />"; echo "token:".$token; if($_GET['target_url'] != "") { } } else { echo "验证失败"; } ?>
        <title>支付宝快捷登录接口</title>
	</head>
    <body>
    </body>
</html>