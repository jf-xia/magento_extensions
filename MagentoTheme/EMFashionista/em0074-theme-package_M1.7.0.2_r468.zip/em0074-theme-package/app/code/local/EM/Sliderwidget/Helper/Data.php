<?php
class EM_Sliderwidget_Helper_Data extends Mage_Core_Helper_Abstract
{
}