<?php
class EM_Productlabels_Block_Adminhtml_Element_Fieldset extends Mage_Adminhtml_Block_Catalog_Form_Renderer_Fieldset_Element
{
}

?>
