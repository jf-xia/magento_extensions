<?php
class EM_Cmswidget_Helper_Data extends Mage_Cms_Helper_Data
{
} 