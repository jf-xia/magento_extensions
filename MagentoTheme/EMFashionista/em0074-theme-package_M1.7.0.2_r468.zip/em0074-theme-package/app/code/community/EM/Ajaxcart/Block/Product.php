<?php
class EM_Ajaxcart_Block_Product extends Mage_Catalog_Block_Product_View
{
	
}