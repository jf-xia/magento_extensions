<?php

class WP_OnePageCheckout_Helper_Data extends Mage_Core_Helper_Abstract
{
    public function getConfigParam($key)
    {
        $key    = 'onepage_checkout/' . $key;
        $data   = Mage::getStoreConfig($key);
        if (!is_array($data)) return trim($data);
            else return array_map('trim', $data);
    }

    public function isIE6()
    {
        if (!isset($_SERVER['HTTP_USER_AGENT'])) return;
        $userAgent = $_SERVER['HTTP_USER_AGENT'];
        preg_match('/MSIE ([0-9]{1,}[\.0-9]{0,})/', $userAgent, $matches);
        if (!isset($matches[1])) return;
        $version = floatval($matches[1]); #Mage::log($version);
        $flag = false; if( $version <= 6.0 ) $flag = true;
        return $flag;
    }

    public function isDisabled()
    {
        if (!self::getConfigParam('general/enabled')) return true;
        if (self::getConfigParam('general/ie6_ignore') && self::isIE6()) return true;
        return false;
    }

    public function getGiftmessageBlock(Varien_Object $entity)
    {
        $type = 'onepage_checkout';
        return Mage::getSingleton('core/layout')->createBlock('giftmessage/message_inline')
            ->setTemplate('webandpeople/onepagecheckout/onepage/shipping_method/giftmessage.phtml')
            ->setId('giftmessage_form_' . $this->_nextId++)
            ->setDontDisplayContainer(false)
            ->setEntity($entity)
            ->setType($type)->toHtml();
    }

    public function checkShippingPrice($shippingAddress)
    {
        // --- a quick fix ---
        $shippingAmount         = $shippingAddress->getShippingAmount();
        $baseCurrencyCode       = Mage::app()->getStore()->getBaseCurrencyCode();
        $currentCurrencyCode    = Mage::app()->getStore()->getCurrentCurrencyCode();
        if ($currentCurrencyCode != $baseCurrencyCode) {
            $shippingAmount = Mage::helper('directory')->currencyConvert($shippingAmount, $baseCurrencyCode, $currentCurrencyCode);
            $shippingAddress->setShippingAmount($shippingAmount);
        }
    }
}
