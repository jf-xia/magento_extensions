Cufon.replace('h1', {fontFamily: 'Century Gothic'});
Cufon.replace('#nav > li > a', {fontFamily: 'Century Gothic'});
Cufon.replace('.product-name', {fontFamily: 'Century Gothic'});
Cufon.replace('.caption.slide-head', {fontFamily: 'Century Gothic'});
Cufon.replace('.caption.slide-slogan', {fontFamily: 'Century Gothic'});
Cufon.replace('.block-account .block-title', {fontFamily: 'Century Gothic'});
Cufon.replace('.block.left-categorys .block-title h2', {fontFamily: 'Century Gothic'});