<?php

class Mage_Catalog_Block_Leftnavigation extends Mage_Core_Block_Template
{
}
